using System;
using Microsoft.EntityFrameworkCore;
using MyWardrobeApp.Data.Models;

namespace MyWardrobeApp.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }
    
    public DbSet<Item> Item { get; set; }
}
