using System;

namespace MyWardrobeApp.Data.Models;

public class Item
{
    public int Id { get; set; }
    public string Type { get; set; } //Rodzaj ubrania np. koszulka
    public string Brand { get; set; } //Marka np. Zara
    public string Size { get; set; } //Rozmiar np. M, L, XL
    public string Material { get; set; } //Materiał np. jedwab
    public DateTime BuyDate { get; set; } //Czas zakupu
    public decimal Price { get; set; } //Cena zakupu
    public string PhotoUrl { get; set; } //Url do zdjęcia np.C:/Ubrania/koszulka_1.jpg

}
