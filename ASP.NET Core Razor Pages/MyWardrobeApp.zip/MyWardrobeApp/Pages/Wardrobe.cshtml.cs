using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MyWardrobeApp.Data;
using MyWardrobeApp.Data.Models;
using MyWardrobeApp.Services;

namespace MyWardrobeApp.Pages
{
    public class WardrobeModel : PageModel
    {
        public required List<Item> Wardrobe { get; set; }
        private IWardrobeService _service;
        public WardrobeModel(IWardrobeService service)
        {
            _service = service;
        }

        public void OnGet()
        {
            // Wardrobe = new List<Item>()
            // {
            //     new Item()
            //     {
            //         Id = 1,
            //         Type = "Koszulka",
            //         Brand = "Zara",
            //         Size = "L",
            //         Material = "bawełna",
            //         BuyDate = DateTime.Now,
            //         Price = 25.99m,
            //         PhotoUrl = "C:/Photos/koszulka1.jpg"
            //     },
            //     new Item()
            //     {
            //         Id = 2,
            //         Type = "Spodnie",
            //         Brand = "Zara",
            //         Size = "L",
            //         Material = "bawełna",
            //         BuyDate = DateTime.Now,
            //         Price = 289.99m,
            //         PhotoUrl = "C:/Photos/spodnie1.jpg"
            //     }
            // };
            Wardrobe = _service.GetAll();
        }
    }
}
