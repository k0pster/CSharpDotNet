using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MyWardrobeApp.Data;
using MyWardrobeApp.Data.Models;
using MyWardrobeApp.Services;

namespace MyWardrobeApp.Pages
{
    public class ClothesModel : PageModel
    {
        public Item? Clothes { get; set; }
        private IWardrobeService _service;
        public ClothesModel(IWardrobeService service)
        {
            _service = service;
        }

        public void OnGet(int id)
        {
            Clothes = _service.Get(id);
        }
    }
}
