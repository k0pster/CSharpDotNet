using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyWardrobeApp.Pages
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
