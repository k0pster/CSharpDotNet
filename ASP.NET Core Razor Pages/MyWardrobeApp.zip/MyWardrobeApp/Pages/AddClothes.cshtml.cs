using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MyWardrobeApp.Data;
using MyWardrobeApp.Data.Models;
using MyWardrobeApp.Services;

namespace MyWardrobeApp.Pages
{
    //[Authorize(Roles = "Admin,Manager")]
    // [Authorize(Policy = "GraduatedOnly")]
    public class AddClothesModel : PageModel
    {
        [BindProperty]
        public string Type { get; set; } //Rodzaj ubrania np. koszulka
        [BindProperty]
        public string Brand { get; set; } //Marka np. Zara
        [BindProperty]
        public string Size { get; set; } //Rozmiar np. M, L, XL
        [BindProperty]
        public string Material { get; set; } //Materiał np. jedwab
        [BindProperty]
        public DateTime BuyDate { get; set; } //Czas zakupu
        [BindProperty]
        public decimal Price { get; set; } //Cena zakupu
        [BindProperty]
        public string PhotoUrl { get; set; } //Url do zdjęcia np.C:/Ubrania/koszulka_1.jpg

        // public void OnGetMyOnClick()
        // {
        //     string stopHere = "";
        // }
        // [BindProperty]
        // public Item Item { get; set; }

        private IWardrobeService _service;
        public AddClothesModel(IWardrobeService service)
        {
            _service = service;
        }

        public void OnGet()
        {
            //Type = "Welcome";
        }
        public IActionResult OnPost()
        {
            //string value = $"{Type} - {Brand} - {Size} - {Material} - {BuyDate} - {Price} - {PhotoUrl}";

            //return Redirect("Clothes");
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var item = new Item()
            {
                Type = Type,
                Brand = Brand,
                Size = Size,
                Price = Price,
                Material = Material,
                BuyDate = BuyDate,
                PhotoUrl = PhotoUrl
            };

            _service.Add(item);

            return Redirect("Wardrobe");
        }
    }
}
