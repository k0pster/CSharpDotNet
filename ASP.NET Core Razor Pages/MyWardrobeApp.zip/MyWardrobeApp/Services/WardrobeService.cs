using System;
using MyWardrobeApp.Data;
using MyWardrobeApp.Data.Models;

namespace MyWardrobeApp.Services;

public class WardrobeService : IWardrobeService
{
    private ApplicationDbContext _context;
    public WardrobeService(ApplicationDbContext context)
    {
        _context = context;
    }

    public void Add(Item item)
    {
        _context.Item.Add(item);
        _context.SaveChanges();
    }

    public Item? Get(int id) => _context.Item.FirstOrDefault(x => x.Id == id);
   

    public List<Item> GetAll() => _context.Item.ToList();

}
