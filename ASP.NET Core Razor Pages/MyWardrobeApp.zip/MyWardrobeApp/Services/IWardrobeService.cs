using System;
using MyWardrobeApp.Data.Models;

namespace MyWardrobeApp.Services;

public interface IWardrobeService
{
    List<Item> GetAll();
    Item? Get(int id);
    void Add(Item item);
}
